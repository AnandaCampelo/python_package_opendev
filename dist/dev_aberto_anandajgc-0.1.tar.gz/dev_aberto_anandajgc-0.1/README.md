Este pacote fornece uma função para obter e exibir informações sobre o último commit realizado, incluindo a data e o autor, no seguinte repositório: 

[open-dev](https://github.com/Insper/open-dev.git)