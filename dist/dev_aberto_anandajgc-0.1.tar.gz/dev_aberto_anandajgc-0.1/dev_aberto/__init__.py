# dev_aberto/__init__.py
from .dev_aberto import hello